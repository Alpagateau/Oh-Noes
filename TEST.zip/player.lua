-- Heavely based on Game Maker's toolkit 
Player = {
}
